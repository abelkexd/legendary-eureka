﻿Public Class Login
    Dim nev As String
    Dim jelszo As String
    Sub login()
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        nev = TextBox1.Text
        jelszo = TextBox2.Text

        If nev = "abelke" And jelszo = "gomba" Then
            login()
        End If
        If nev = "terdik" And jelszo = "terdik" Then
            login()
        End If
        If nev = "heiner" And jelszo = "én vagyok a rates ernő" Then
            login()
        End If
        If nev = "admin" And jelszo = "admin" Then
            'login()
            MessageBox.Show("hé")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MessageBox.Show("Be kell jelentkezned az OrbánVPN v2 használatához", "Be kell jelentkezned", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
End Class