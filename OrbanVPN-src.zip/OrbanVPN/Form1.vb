﻿Public Class Form1
    Dim wait As Integer
    Dim loc As String


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        loc = ComboBox1.Text
        While wait < 100
            Label3.Text = ("csatlakozás " + wait.ToString + "%")
            wait = wait + 1
            Threading.Thread.Sleep(20)

        End While


        If wait = (100) Then

            Label3.Text = ("Csatlakozva (" + loc + ")")
        End If
        If loc = "válasz hej" Then
            Label3.Text = ("kurva anyád")
        End If


        Timer1.Start()

    End Sub

    Private Sub Form1_HelpButtonClicked(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles MyBase.HelpButtonClicked

    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing


    End Sub
End Class
